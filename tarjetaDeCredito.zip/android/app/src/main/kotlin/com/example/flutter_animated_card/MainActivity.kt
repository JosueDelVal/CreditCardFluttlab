package com.example.flutter_animated_card

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
